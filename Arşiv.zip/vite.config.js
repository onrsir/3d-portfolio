export default {
  base: '/3d-portfolio/',
};
